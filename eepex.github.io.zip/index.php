
<?php
/*
Template Name: EEPEx Home
*/
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ARrestro -2022</title>
    <link rel="icon" type="image/x-icon" href="./assets/images/logo.png">

    <link rel="stylesheet" href="./style/style.css">
    <link rel="stylesheet" href="/library/bootstrap.css">
    <link rel="stylesheet" href="./library/swiper.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.8.0/dist/leaflet.css"
        integrity="sha512-hoalWLoI8r4UszCkZ5kL8vayOGVae1oxXe/2A4AO6J9+580uKHDO3JdHb7NzwwzK5xr/Fs0W40kiNHxM9vyTtQ=="
        crossorigin="" />
    <script src="https://unpkg.com/leaflet@1.8.0/dist/leaflet.js"
        integrity="sha512-BB3hKbKWOc9Ez/TAwyWxNXeoV9c1v6FIeYiBieIWkpLjauysF18NzgR1MBNBXf8/KABdlkX68nAhlwcDFLGPCQ=="
        crossorigin=""></script>
</head>

<body>
    <script src="./library/jquery.js"></script>
    <script src="./library/bootstrap.js"></script>
    <script src="./library/three.js"></script>
    <script src="./library/swiper.js"></script>
    <script src="https://kit.fontawesome.com/3307952f9a.js" crossorigin="anonymous"></script>
    <script src="./script/script.js"></script>


    <div class="d-flex sticky-top"
        style="padding-top:10px;padding-right: 40px;border-bottom: solid 1px rgb(216, 216, 216);background-color: white;">
        <div style="flex: 0.7;">
            <img src="./UI UX/Logo.png" class="title-image" />
        </div>

        <div class="row" style="flex:1;padding-top:10px ;">
            <div class="title-tab-div d-none d-sm-block col-2">
                <a class="title-link" href="#bottom">
                    <div class="title-tabs">
                        <span class="title-link">
                            Home
                        </span>
                    </div>
                </a>
            </div>
            <div class="title-tab-div d-none d-sm-block col-2">
                <a class="title-link" href="#bottom">
                    <div class="title-tabs">
                        <span class="title-link">
                            Contact
                        </span>
                    </div>
                </a>
            </div>
            <div class="title-tab-div d-none d-sm-block col-2">
                <a class="title-link" href="#bottom">
                    <div class="title-tabs">
                        <span class="title-link">
                            Events
                        </span>
                    </div>
                </a>
            </div>

            <div class="title-tab-div d-none d-sm-block col-2">
                <a class="title-link" href="#bottom">
                    <div class="title-tabs">
                        <span class="title-link">
                            Notices
                        </span>
                    </div>
                </a>
            </div>

            <div class="title-tab-div d-none d-sm-block col-2">

                <div class="title-tabs-order">
                    <i class="fa fa-info"
                        style="padding: 5px;background-color:white;border-radius:100%;width:22px;color:black;margin-right:10px"></i>Sponsors
                </div>
            </div>
        </div>
        <div class="dropdown d-block d-md-none">
            <button style="border: none;background-color:#fff" class="dropright" type="button" id="dropdownMenuButton"
                data-toggle="dropdown">
                <i class="fa fa-bars "
                    style="background-color: #FF6600;color:white;padding: 10px;margin-top: 30px;"></i>
            </button>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton">
                <a class="dropdown-item" href="#">Home</a>
                <a class="dropdown-item" href="#">About</a>
                <a class="dropdown-item" href="#">Contact</a>
            </div>
        </div>

    </div>

    <div class="modal fade bd-example-modal-lg " tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg qr-modal-container">
            <div class="modal-content text-center" style="padding: 40px;">
                <button type="button" style="margin-left: auto ;font-size: 20px;" class="close" data-dismiss="modal"
                    aria-label="Close">
                    <span aria-hidden="true" style="margin: 20px;margin-top:30px;font-size: 20px;">&times;</span>
                </button>
                <div class="text-align" id="qrModal"></div>
                <div class="btn btn-primary" style="width: 50%;text-align:center;margin:auto;margin-top:20px">Open our
                    app and scan this LOGO</div>
            </div>
        </div>
    </div>
    <div class="modal fade bd-example-modal-lg-2" tabindex="-1" role="dialog" aria-labelledby="secondLargeModal"
        aria-hidden="true" id="LocationModal">
        <div class="modal-dialog modal-lg location-modal-container">
            <div class="modal-content location-modal-content">
                <button type="button" style="margin-left: auto ;font-size: 20px;" class="close" data-dismiss="modal"
                    aria-label="Close">
                    <span aria-hidden="true" style="margin: 20px;margin-top:30px;font-size: 20px;">&times;</span>
                </button>
                <div class="locationModal row g-0" id="">
                    <div class="col-md-4 text-center">
                        <img src="./assets/images/image3.jpg" class="restaurant-image-small" style="margin: auto;"
                            alt="">
                        <div class="location-modal-title">
                            Burger King
                        </div>
                        <div class="location-modal-location">
                            Dhulikhel, Kavre
                        </div>

                        <button data-toggle="modal" onclick="addImage('./assets/images/burgerKing.png');closeModalAll()"
                            data-target=".bd-example-modal-lg" class="btn btn-primary view-in-ar"
                            style="margin-top: 30px;">
                            View In AR

                        </button>
                    </div>
                    <div class="col-md-8 " style="display:flex;flex-direction:column">

                        <div id="map"></div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="swiper">
        <!-- Additional required wrapper -->
        <div class="swiper-wrapper">
            <!-- Slides -->
            <div class="swiper-slide">
                <div class="row">
                    <span class="slider-images-container text-center">
                        <a href="" style="text-decoration: none;color:black">
                            <img src="./assets/images/image1.jpg" class="restaurant-image-large" alt="">
                            <div class="text-center card-restro-name">Hackathon</div>
                            <div class="swiper-slide-caption  g-0">
                                <a class="col-4">
                                    <i class="fa fa-bullhorn slider-images-container-icon"></i>
                                </a>
                                <a class="col-4">
                                    <i class="fa fa-user-astronaut slider-images-container-icon"></i>
                                </a>
                                <a class="col-4">
                                    <i class="fa fa-info slider-images-container-icon"></i>
                                </a>
                            </div>
                        </a>
                    </span>

                    <span class="slider-images-container text-center">
                        <a href="" style="text-decoration: none;color:black">

                            <img src="./assets/images/image4.jpg" class="restaurant-image-large" alt="">
                            <div class="text-center card-restro-name">Gaming</div>
                            <div class="swiper-slide-caption  g-0">
                                <a class="col-4">
                                    <i class="fa fa-bullhorn slider-images-container-icon"></i>
                                </a>
                                <a class="col-4">
                                    <i class="fa fa-user-astronaut slider-images-container-icon"></i>
                                </a>
                                <a class="col-4">
                                    <i class="fa fa-info slider-images-container-icon"></i>
                                </a>
                            </div>
                        </a>
                    </span>

                    <span class="slider-images-container text-center">
                        <a href="" style="text-decoration: none;color:black">

                            <img src="./assets/images/image5.jpg" class="restaurant-image-large" alt="">
                            <div class="text-center card-restro-name">Acoustic</div>
                            <div class="swiper-slide-caption  g-0">
                                <a class="col-4">
                                    <i class="fa fa-bullhorn slider-images-container-icon"></i>
                                </a>
                                <a class="col-4">
                                    <i class="fa fa-user-astronaut slider-images-container-icon"></i>
                                </a>
                                <a class="col-4">
                                    <i class="fa fa-info slider-images-container-icon"></i>
                                </a>
                            </div>
                        </a>
                    </span>

                    <span class="slider-images-container text-center">
                        <a href="" style="text-decoration: none;color:black">

                            <img src="./assets/images/image7.jpg" class="restaurant-image-large" alt="">
                            <div class="text-center card-restro-name">Robo War </div>
                            <div class="swiper-slide-caption  g-0">
                                <a class="col-4">
                                    <i class="fa fa-bullhorn slider-images-container-icon"></i>
                                </a>
                                <a class="col-4">
                                    <i class="fa fa-user-astronaut slider-images-container-icon"></i>
                                </a>
                                <a class="col-4">
                                    <i class="fa fa-info slider-images-container-icon"></i>
                                </a>
                            </div>
                        </a>
                    </span>



                </div>
            </div>
            <div class="swiper-slide">
                <div class="row">
                    <span class="slider-images-container text-center">
                        <a href="" style="text-decoration: none;color:black">

                            <img src="./assets/images/image6.jpg" class="restaurant-image-large" alt="">
                            <div class="text-center card-restro-name">Circuit Competition</div>
                            <div class="swiper-slide-caption  g-0">
                                <a class="col-4">
                                    <i class="fa fa-bullhorn slider-images-container-icon"></i>
                                </a>
                                <a class="col-4">
                                    <i class="fa fa-user-astronaut slider-images-container-icon"></i>
                                </a>
                                <a class="col-4">
                                    <i class="fa fa-info slider-images-container-icon"></i>
                                </a>
                            </div>
                        </a>
                    </span>

                    <span class="slider-images-container text-center">
                        <a href="" style="text-decoration: none;color:black">

                            <img src="./assets/images/image8.jpg" class="restaurant-image-large" alt="">
                            <div class="text-center card-restro-name">Talk Show</div>
                            <div class="swiper-slide-caption  g-0">
                                <a class="col-4">
                                    <i class="fa fa-bullhorn slider-images-container-icon"></i>
                                </a>
                                <a class="col-4">
                                    <i class="fa fa-user-astronaut slider-images-container-icon"></i>
                                </a>
                                <a class="col-4">
                                    <i class="fa fa-info slider-images-container-icon"></i>
                                </a>
                            </div>
                        </a>
                    </span>

                    <span class="slider-images-container text-center">
                        <a href="" style="text-decoration: none;color:black">

                            <img src="./assets/images/image3.jpg" class="restaurant-image-large" alt="">
                            <div class="text-center card-restro-name">Electronics Training</div>
                            <div class="swiper-slide-caption  g-0">
                                <a class="col-4">
                                    <i class="fa fa-bullhorn slider-images-container-icon"></i>
                                </a>
                                <a class="col-4">
                                    <i class="fa fa-user-astronaut slider-images-container-icon"></i>
                                </a>
                                <a class="col-4">
                                    <i class="fa fa-info slider-images-container-icon"></i>
                                </a>
                            </div>
                        </a>
                    </span>

                    <span class="slider-images-container text-center">
                        <a href="" style="text-decoration: none;color:black">

                            <img src="./assets/images/image2.jpg" class="restaurant-image-large" alt="">
                            <div class="text-center card-restro-name">Sports</div>
                            <div class="swiper-slide-caption  g-0">
                                <a class="col-4">
                                    <i class="fa fa-bullhorn slider-images-container-icon"></i>
                                </a>
                                <a class="col-4">
                                    <i class="fa fa-user-astronaut slider-images-container-icon"></i>
                                </a>
                                <a class="col-4">
                                    <i class="fa fa-info slider-images-container-icon"></i>
                                </a>
                            </div>
                        </a>
                    </span>



                </div>
            </div>
        </div>
        <span class="swiper-button-prev" id="swiper-btn-1"></span>
        <span class="swiper-button-next" id="swiper-btn-2"></span>
    </div>


    <div class="newsletter-container text-center">
        <div class="newsletter-title">
            Newsletter
        </div>
        <div class="newsletter-small-info-text">
            Get Timely Updates About Your Favourite EEPEx Events
        </div>
        <div class="input-field-div">
            <input type="text" class="text-field-1" placeholder="Your Email">
            <i class="fa fa-paper-plane"
                style="color: white;background-color: green;padding: 14px;padding-left: 20px;padding-right: 20px;margin: 0px;"></i>
        </div>
    </div>


    <div class="footer-container">
        <div class="footer-section-1 d-flex flex-column col-5" style="flex: 1.5;">
            <div class="app-footer-title">EEPEx 2022</div>
            <div class="app-footer-desc">EEPEx 2022 is the biggest electrical and electronics project of 2022. Hosted by
                Society of Electrical and Electronics Engineering of Kathmandu University. This event will provide you
                the biggest experience of your lifetime.
            </div>
            <div class="fa-footer-div" style="margin-top:20px">
                <i class="fa fa-facebook fa-footer-icon" style="background-color: blue"></i>
                <i class="fa fa-instagram fa-footer-icon" style="background-color: #E12F6B"></i>
                <i class="fa fa-twitter fa-footer-icon" style="background-color: #1D9BF0;"></i>
                <i class="fa fa-github fa-footer-icon" style="background-color: black"></i>
                <i class="fa fa-linkedin fa-footer-icon" style="background-color: #0E76A8;"></i>
            </div>
        </div>
        <div class="footer-section-2 col-4">
            <div class="useful-links">Useful Links</div>
            <div class="d-flex row">
                <div class="col-6" style="display: flex;flex-direction:column">
                    <div class="links-list-item">Home</div>
                    <div class="links-list-item">FAQ</div>
                    <div class="links-list-item">Events</div>
                    <div class="links-list-item">Bug Report</div>
                </div>
                <div class="col-6" style="display: flex;flex-direction:column">
                    <div class="links-list-item">Notices</div>
                    <div class="links-list-item">Organizers</div>
                    <div class="links-list-item">Competition</div>
                    <div class="links-list-item">Code Of Conduct</div>
                </div>
            </div>
        </div>
        <div class="footer-section-3 col-3">
            <div class="useful-links">Contact Us</div>
            <div class="">
                <div class="">
                    <div class="links-list-item">
                        <i class="fa fa-map-pin contact-us-icon"></i>
                        Dhulikhel, Kavre
                    </div>
                    <div class="links-list-item">
                        <i class="fa fa-phone contact-us-icon"></i>
                        9844442363
                    </div>
                    <div class="links-list-item">
                        <i class="fa fa-envelope contact-us-icon"></i>
                        siddharthaghimire@gmail.com
                    </div>
                    <div class="links-list-item d-flex" style="margin-top: 20px;">
                        <i class="fa fa-paypal contact-us-icon"></i>
                        <i class="fa fa-amazon contact-us-icon"></i>
                        <i class="fa fa-google contact-us-icon"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="bottom"></div>


    <script>
        function closeModalAll() {
            $('#LocationModal').modal('hide');

        }
        function addImage(info) {

            var img = document.createElement("img");
            img.src = info;
            img.style = "width: 70%;margin: auto;"
            var block = document.getElementById("qrModal");
            block.innerHTML = "";
            block.appendChild(img);
        }
        var stadium = new L.LatLng(27.621074, 85.552846);

        var map = L.map('map').setView(stadium, 15);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);
        var marker = L.marker([27.621074, 85.552846]);

        // Adding marker to the map
        marker.addTo(map);


        var modal = document.getElementById("LocationModal")
        $("#LocationModal").on('shown.bs.modal', function () {
            setTimeout(function () {
                map.invalidateSize()
            }, 1)
        })

        const swiper = new Swiper('.swiper', {
            // Optional parameters
            direction: 'horizontal',
            loop: true,
            speed: 3000,

            // If we need pagination
            pagination: {
                el: '.swiper-pagination',
            },

            // Navigation arrows
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },

            // And if we need scrollbar
            scrollbar: {
                el: '.swiper-scrollbar',
            },
        });
        if (screen.width < 600) {
            swiper.destroy()
            var elem = document.getElementById("swiper-btn-1");
            elem.remove();
            elem = document.getElementById("swiper-btn-2");
            elem.remove();

        }
    </script>

</body>

</html>